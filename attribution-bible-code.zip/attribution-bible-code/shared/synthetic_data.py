"""
Synthetic data generators for The Marketing Attribution Bible code companion.

Every generator returns data with a KNOWN ground truth, so you can check
whether an estimator recovers the right answer. That is the whole point: on
real data you never find out, which is why it is worth practising on data
where you do.

All generators take a `seed` so results are reproducible.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def make_geo_experiment(
    n_markets: int = 40,
    n_weeks_pre: int = 26,
    n_weeks_post: int = 8,
    true_lift: float = 0.06,
    treated_fraction: float = 0.5,
    market_sd: float = 0.35,
    week_sd: float = 0.05,
    noise_sd: float = 0.08,
    ar1: float = 0.6,
    n_factors: int = 3,
    factor_sd: float = 0.10,
    seed: int = 42,
) -> tuple[pd.DataFrame, dict]:
    """
    Panel of markets x weeks for a geo holdout experiment.

    Structure of the data-generating process, in logs:

        log(sales) = market_effect + week_effect + treatment_effect + noise

    - market_effect  : markets differ persistently in size (big city vs small)
    - week_effect    : shared seasonality, hits treated and control alike
    - factor_effect  : latent common factors with market-specific loadings
    - treatment_effect: log1p(true_lift) applied to treated markets, post only
    - noise          : AR(1) within each market, not independent across weeks

    The latent factors are what make some markets genuinely resemble others -
    shared regional economic conditions, category trends, competitor activity.
    Markets with similar loadings track each other over time. This matters
    because synthetic control (03_synthetic_control.py) works by finding donor
    markets that resemble the treated one, and with no factor structure there
    is nothing for it to find. Set `n_factors=0` to switch it off and watch
    synthetic control stop working.

    The AR(1) noise matters. Real weekly sales in a market are correlated with
    last week's sales, which means market-weeks are not independent
    observations. That is precisely why standard errors have to be clustered
    at the market level, and generating independent noise would make this
    dataset quietly understate how much clustering matters.

    Because the week effect is shared, it cancels in a difference-in-differences
    comparison. That is the mechanism Chapter 2 describes: the holiday hits both
    groups, so it drops out of the comparison without being modelled.

    Parameters
    ----------
    n_markets : number of geographic units
    n_weeks_pre / n_weeks_post : weeks before and after treatment starts
    true_lift : the effect you are trying to recover (0.06 = 6% lift)
    treated_fraction : share of markets assigned to treatment
    market_sd : SD of persistent market-level differences (log scale)
    week_sd : SD of shared week effects (log scale)
    noise_sd : SD of idiosyncratic noise (log scale)

    Returns
    -------
    (df, truth)
        df : long panel with columns
             market, week, treated, post, sales
        truth : dict of the parameters used, including `true_lift`
    """
    rng = np.random.default_rng(seed)

    n_treated = int(round(n_markets * treated_fraction))
    # Random assignment. Note this is assignment by coin flip, not "the East
    # region is the control" - see Chapter 11 on why that distinction matters.
    assignment = np.zeros(n_markets, dtype=int)
    assignment[rng.permutation(n_markets)[:n_treated]] = 1

    market_effect = rng.normal(10.0, market_sd, size=n_markets)
    n_weeks = n_weeks_pre + n_weeks_post

    # Latent common factors: smooth random walks, so markets loading on the
    # same factor drift together in a way a weighted blend can reproduce.
    if n_factors > 0:
        innovations = rng.normal(0.0, 1.0, size=(n_weeks, n_factors))
        factors = np.cumsum(innovations, axis=0)
        factors = (factors - factors.mean(axis=0)) / (factors.std(axis=0) + 1e-12)
        loadings = rng.normal(0.0, 1.0, size=(n_markets, n_factors))
        # (n_markets, n_weeks)
        factor_effect = factor_sd * (loadings @ factors.T)
    else:
        factor_effect = np.zeros((n_markets, n_weeks))

    week_effect = rng.normal(0.0, week_sd, size=n_weeks)
    # Add a seasonal ramp in the post period so a naive pre/post comparison
    # is actively misleading - this is the trap the direct mail team fell into.
    week_effect[n_weeks_pre:] += np.linspace(0.04, 0.10, n_weeks_post)

    rows = []
    for m in range(n_markets):
        # AR(1) noise path for this market. Scaled so the marginal SD of the
        # noise stays at `noise_sd` regardless of the autocorrelation, which
        # keeps `ar1` and `noise_sd` independent knobs.
        innov_sd = noise_sd * np.sqrt(max(1.0 - ar1**2, 1e-12))
        eps = np.empty(n_weeks)
        eps[0] = rng.normal(0.0, noise_sd)
        for w in range(1, n_weeks):
            eps[w] = ar1 * eps[w - 1] + rng.normal(0.0, innov_sd)

        for w in range(n_weeks):
            post = int(w >= n_weeks_pre)
            treat_now = assignment[m] * post
            log_sales = (
                market_effect[m]
                + week_effect[w]
                + factor_effect[m, w]
                + np.log1p(true_lift) * treat_now
                + eps[w]
            )
            rows.append(
                {
                    "market": f"M{m:03d}",
                    "week": w,
                    "treated": assignment[m],
                    "post": post,
                    "sales": float(np.exp(log_sales)),
                }
            )

    df = pd.DataFrame(rows)
    truth = {
        "true_lift": true_lift,
        "n_markets": n_markets,
        "n_treated": n_treated,
        "n_weeks_pre": n_weeks_pre,
        "n_weeks_post": n_weeks_post,
        "market_sd": market_sd,
        "noise_sd": noise_sd,
        "ar1": ar1,
        "n_factors": n_factors,
        "factor_sd": factor_sd,
        "seed": seed,
    }
    return df, truth


def make_user_experiment(
    n_users: int = 80_000,
    holdout_fraction: float = 0.5,
    baseline_revenue: float = 42.0,
    revenue_sd: float = 65.0,
    true_lift: float = 0.03,
    pre_period_correlation: float = 0.6,
    seed: int = 7,
) -> tuple[pd.DataFrame, dict]:
    """
    User-level holdout experiment with a pre-period covariate.

    The pre-period revenue column is what makes CUPED possible (see 04_cuped.py).
    `pre_period_correlation` is a knob on how strongly past behaviour predicts
    future behaviour, which is what determines how much variance CUPED can
    remove.

    Note: it is a knob, not an exact target. Poisson count sampling and
    per-order noise put a ceiling on the achievable correlation, so asking for
    0.6 yields a realised correlation of roughly 0.46. The realised value is
    returned in `truth["observed_pre_post_corr"]` - always read it from there
    rather than assuming you got what you asked for. Realised values land in
    the 0.3-0.5 range, which is typical of real consumer businesses.

    Revenue is generated as a spend-or-not mixture rather than a plain normal,
    because real revenue is zero-inflated and right-skewed, and estimators
    that look fine on normal data sometimes behave differently on realistic
    revenue distributions.

    Returns
    -------
    (df, truth)
        df : columns user_id, treated, pre_revenue, revenue
        truth : dict including `true_lift`
    """
    rng = np.random.default_rng(seed)

    treated = (rng.random(n_users) > holdout_fraction).astype(int)

    # Each user has a persistent purchase rate and a persistent basket size.
    # Both periods are drawn conditional on those, which is what creates the
    # pre/post correlation CUPED exploits. This is a standard NBD-style setup:
    # heterogeneous rates across users, Poisson counts within a user.
    #
    # `persistence` controls how much of the user's rate carries into the post
    # period. It is calibrated below so the realised correlation lands near the
    # requested `pre_period_correlation`.
    persistence = float(np.clip(pre_period_correlation, 0.0, 0.95)) ** 0.5

    rate = rng.gamma(shape=0.8, scale=1.1, size=n_users)
    basket = rng.gamma(shape=3.0, scale=baseline_revenue / 3.0, size=n_users)

    rate_post = persistence * rate + (1.0 - persistence) * rng.gamma(
        shape=0.8, scale=1.1, size=n_users
    )
    basket_post = persistence * basket + (1.0 - persistence) * rng.gamma(
        shape=3.0, scale=baseline_revenue / 3.0, size=n_users
    )

    pre_orders = rng.poisson(rate, size=n_users)
    post_orders = rng.poisson(rate_post * (1.0 + true_lift * treated), size=n_users)

    # Multiply orders by basket size, with a little per-order noise so revenue
    # is not a deterministic function of the count.
    pre_revenue = pre_orders * basket * rng.lognormal(0.0, 0.25, size=n_users)
    post_revenue = post_orders * basket_post * rng.lognormal(0.0, 0.25, size=n_users)

    df = pd.DataFrame(
        {
            "user_id": np.arange(n_users),
            "treated": treated,
            "pre_revenue": pre_revenue,
            "revenue": post_revenue,
        }
    )
    truth = {
        "true_lift": true_lift,
        "n_users": n_users,
        "holdout_fraction": holdout_fraction,
        "revenue_sd": float(df["revenue"].std()),
        "observed_pre_post_corr": float(df["pre_revenue"].corr(df["revenue"])),
        "seed": seed,
    }
    return df, truth


def banner(title: str, width: int = 72) -> None:
    """Consistent section headers so script output is readable."""
    print()
    print("=" * width)
    print(title)
    print("=" * width)


def kv(label: str, value, width: int = 44) -> None:
    """Aligned label/value printing."""
    print(f"{label:<{width}} {value}")
