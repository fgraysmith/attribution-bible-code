# Chapter 14 — Implementing an MMM

Code lands when the chapter publishes (12 November 2026).

A PyMC-Marketing walkthrough: adstock and saturation specification, prior setting, posterior predictive checks, diagnosing collinearity, and budget optimisation from the fitted model.

Prior setting connects back to Chapter 6. The code will show how to convert an experimental lift result into a prior on a channel coefficient, and the width multiplier that keeps parameter recovery stable.
