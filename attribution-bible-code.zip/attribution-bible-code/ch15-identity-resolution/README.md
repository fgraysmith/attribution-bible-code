# Chapter 15 — Implementing Identity Resolution

Code lands when the chapter publishes (19 November 2026).

A full matching pipeline: name normalisation, deterministic matching, heuristic blocking to keep the candidate space tractable, several string-similarity measures fed into a classifier, and validation on a labelled sample.

The emphasis is on what Chapter 8 argues is the real decision — the threshold. The code will show precision and recall across thresholds, so the trade-off is visible rather than assumed.
