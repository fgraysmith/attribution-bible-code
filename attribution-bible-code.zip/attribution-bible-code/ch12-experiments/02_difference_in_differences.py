"""
Chapter 12 - Difference-in-differences.

The workhorse estimator for a geo experiment. Three versions, in increasing
order of how much you should trust them:

  1. The 2x2 arithmetic, by hand. Shows the mechanism.
  2. Regression DiD with market and week fixed effects.
  3. The same regression with cluster-robust standard errors, plus
     randomisation inference as a check when the cluster count is small.

The dataset has a known true lift, so you can see whether each version
recovers it. It also has a seasonal ramp in the post period, which means the
naive pre/post comparison is actively misleading - that is deliberate.

Run:  python 02_difference_in_differences.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from shared.synthetic_data import banner, kv, make_geo_experiment


def naive_pre_post(df: pd.DataFrame) -> float:
    """
    The comparison you should not use: treated markets, after vs before.

    This is what the direct mail team in Chapter 2 was doing. It attributes
    the entire pre/post change to the marketing, including whatever the
    calendar was going to do anyway.
    """
    t = df[df["treated"] == 1]
    return float(t.loc[t.post == 1, "sales"].mean() / t.loc[t.post == 0, "sales"].mean() - 1)


def did_by_hand(df: pd.DataFrame) -> dict:
    """
    The 2x2 difference-in-differences, in logs.

    lift = (treated_post - treated_pre) - (control_post - control_pre)

    Working in logs makes the result a multiplicative lift. The second
    difference is what removes the shared seasonal movement: the holiday hits
    both arms, so subtracting the control's change cancels it.
    """
    d = df.copy()
    d["log_sales"] = np.log(d["sales"])
    cell = d.groupby(["treated", "post"])["log_sales"].mean().unstack()

    treated_change = cell.loc[1, 1] - cell.loc[1, 0]
    control_change = cell.loc[0, 1] - cell.loc[0, 0]
    did_log = treated_change - control_change

    return {
        "treated_change_log": float(treated_change),
        "control_change_log": float(control_change),
        "did_log": float(did_log),
        "lift": float(np.expm1(did_log)),
    }


def did_regression(df: pd.DataFrame, cluster: bool = True) -> dict:
    """
    Regression DiD with market and week fixed effects.

        log(sales) ~ treated:post + C(market) + C(week)

    The interaction coefficient is the effect. Market fixed effects absorb
    persistent size differences; week fixed effects absorb anything that moved
    for everyone that week.

    On standard errors: observations within a market are correlated across
    weeks, so default (iid) standard errors are far too small. Clustering at
    the market level is the minimum fix - note the unit of clustering is the
    unit of RANDOMISATION, which is the market, not the week and not the
    customer.
    """
    d = df.copy()
    d["log_sales"] = np.log(d["sales"])

    model = smf.ols("log_sales ~ treated:post + C(market) + C(week)", data=d)
    if cluster:
        res = model.fit(cov_type="cluster", cov_kwds={"groups": d["market"]})
    else:
        res = model.fit()

    term = "treated:post"
    coef = float(res.params[term])
    se = float(res.bse[term])
    ci_low, ci_high = res.conf_int().loc[term].tolist()

    return {
        "coef_log": coef,
        "se_log": se,
        "lift": float(np.expm1(coef)),
        "ci_lift": (float(np.expm1(ci_low)), float(np.expm1(ci_high))),
        "p_value": float(res.pvalues[term]),
        "n_obs": int(res.nobs),
    }


def randomisation_inference(df: pd.DataFrame, n_draws: int = 2000, seed: int = 0) -> dict:
    """
    Randomisation inference: a p-value that does not rely on asymptotics.

    Cluster-robust standard errors are derived from large-sample theory. With
    40 markets - and especially with fewer - they are biased downward, so your
    intervals are too narrow and your p-values too small. This is a known and
    well-documented problem, and it is easy to hit in geo testing, where 20-50
    markets is normal.

    The fix is to use the experiment's own randomisation as the null
    distribution: reshuffle the treatment labels across markets many times,
    recompute the estimate each time, and ask how extreme the real estimate
    looks against that distribution. No distributional assumption required.
    """
    rng = np.random.default_rng(seed)

    d = df.copy()
    d["log_sales"] = np.log(d["sales"])

    markets = d["market"].unique()
    n_treated = int(d.groupby("market")["treated"].first().sum())

    def point_estimate(assignment_map: dict) -> float:
        tmp = d.copy()
        tmp["t"] = tmp["market"].map(assignment_map)
        cell = tmp.groupby(["t", "post"])["log_sales"].mean().unstack()
        return (cell.loc[1, 1] - cell.loc[1, 0]) - (cell.loc[0, 1] - cell.loc[0, 0])

    observed_map = d.groupby("market")["treated"].first().to_dict()
    observed = point_estimate(observed_map)

    null_draws = np.empty(n_draws)
    for i in range(n_draws):
        shuffled = np.zeros(len(markets), dtype=int)
        shuffled[rng.permutation(len(markets))[:n_treated]] = 1
        null_draws[i] = point_estimate(dict(zip(markets, shuffled)))

    # Two-sided p-value: how often does a random reassignment produce an
    # effect at least as large in magnitude as the one we actually observed?
    p_value = float((np.abs(null_draws) >= abs(observed)).mean())

    return {
        "observed_log": float(observed),
        "observed_lift": float(np.expm1(observed)),
        "null_sd_log": float(null_draws.std()),
        "p_value": p_value,
        "n_draws": n_draws,
    }


def main() -> None:
    df, truth = make_geo_experiment(n_markets=40, n_weeks_pre=26, n_weeks_post=8, true_lift=0.06)

    banner("THE DATA")
    kv("Markets", truth["n_markets"])
    kv("  treated / control", f"{truth['n_treated']} / {truth['n_markets'] - truth['n_treated']}")
    kv("Weeks pre / post", f"{truth['n_weeks_pre']} / {truth['n_weeks_post']}")
    kv("TRUE LIFT (what we want to recover)", f"{truth['true_lift']:.2%}")

    banner("1. NAIVE PRE/POST - THE WRONG ANSWER")
    naive = naive_pre_post(df)
    kv("Naive pre/post lift (treated only)", f"{naive:.2%}")
    kv("True lift", f"{truth['true_lift']:.2%}")
    kv("Overstated by", f"{naive / truth['true_lift'] - 1:.0%}")
    print()
    print(
        "The post period contains a seasonal ramp that would have happened\n"
        "with no marketing at all. Pre/post attributes it to the campaign."
    )

    banner("2. DIFFERENCE-IN-DIFFERENCES BY HAND")
    hand = did_by_hand(df)
    kv("Treated change (log)", f"{hand['treated_change_log']:+.4f}")
    kv("Control change (log)", f"{hand['control_change_log']:+.4f}")
    kv("Difference of differences (log)", f"{hand['did_log']:+.4f}")
    kv("Implied lift", f"{hand['lift']:.2%}")
    print()
    print(
        "The control group's change captures the seasonality. Subtracting it\n"
        "leaves the treatment effect. No seasonal model required - this is\n"
        "what randomisation buys you."
    )

    banner("3. REGRESSION DiD WITH FIXED EFFECTS")
    naive_se = did_regression(df, cluster=False)
    clustered = did_regression(df, cluster=True)

    kv("Estimated lift", f"{clustered['lift']:.2%}")
    kv("True lift", f"{truth['true_lift']:.2%}")
    kv("95% CI on lift", f"[{clustered['ci_lift'][0]:.2%}, {clustered['ci_lift'][1]:.2%}]")
    kv("Observations", f"{clustered['n_obs']:,}")
    print()
    kv("SE with iid (wrong) errors", f"{naive_se['se_log']:.5f}")
    kv("SE clustered by market", f"{clustered['se_log']:.5f}")
    kv("Ratio", f"{clustered['se_log'] / naive_se['se_log']:.2f}x")
    print()
    ratio = clustered["se_log"] / naive_se["se_log"]
    print(
        f"The clustered standard error is {ratio:.1f}x the iid one, which means\n"
        f"the iid confidence interval would be roughly {1 / ratio:.0%} as wide as\n"
        "it should be. You would report half the uncertainty you actually have.\n\n"
        "The cause is that weekly sales within a market are autocorrelated, so\n"
        "1,360 market-weeks are not 1,360 independent observations. You have 40\n"
        "independent units - the markets you randomised. This is the single most\n"
        "common way geo tests end up reporting false precision."
    )

    banner("4. RANDOMISATION INFERENCE - A CHECK ON THE ASYMPTOTICS")
    ri = randomisation_inference(df, n_draws=2000)
    kv("Observed lift", f"{ri['observed_lift']:.2%}")
    kv("SD of null distribution (log)", f"{ri['null_sd_log']:.4f}")
    kv("Randomisation p-value", f"{ri['p_value']:.4f}")
    kv("Cluster-robust p-value", f"{clustered['p_value']:.4f}")
    print()
    print(
        f"Compare the null SD ({ri['null_sd_log']:.4f}) to the clustered standard\n"
        f"error ({clustered['se_log']:.4f}). They are close, which tells you the\n"
        "cluster-robust interval is trustworthy on this dataset - the asymptotics\n"
        "are holding up at 40 markets.\n\n"
        "That agreement is the result you want and cannot assume. Cluster-robust\n"
        "errors are derived from large-sample theory and are biased downward when\n"
        "clusters are few. Randomisation inference assumes nothing: it asks how\n"
        "often a random reassignment of markets would produce an effect this\n"
        "large. When the two agree, use the clustered interval. When they do not,\n"
        "believe the randomisation test.\n\n"
        "Worth running whenever you have fewer than about 50 markets, which in\n"
        "geo testing is most of the time."
    )


if __name__ == "__main__":
    main()
