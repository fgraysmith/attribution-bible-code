"""
Chapter 12 - Power and minimum detectable effect.

This is the calculation Chapter 11 says to run before committing any budget:
given the units you have, the noise in your outcome, the holdout size and the
duration, what is the smallest lift you could reliably detect?

Then you compare that number to the lift you actually think is plausible. If
the detectable effect is bigger than the plausible effect, the test will come
back inconclusive - and "inconclusive" gets read around the business as
"it didn't work", which is a different and wrong conclusion.

Run:  python 01_power_and_mde.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from shared.synthetic_data import banner, kv, make_geo_experiment, make_user_experiment


def mde_two_sample(
    sd: float,
    n_treat: int,
    n_control: int,
    alpha: float = 0.05,
    power: float = 0.80,
) -> float:
    """
    Minimum detectable effect for a two-sample comparison of means,
    in the same units as `sd`.

    MDE = (z_{1-alpha/2} + z_{power}) * SE_of_difference

    This is the standard normal approximation. It is accurate for the sample
    sizes marketing experiments usually involve; for very small samples you
    would use the t distribution instead.

    Parameters
    ----------
    sd : standard deviation of the outcome at the unit of randomisation
    n_treat, n_control : units in each arm
    alpha : two-sided significance level
    power : probability of detecting a true effect of exactly the MDE
    """
    if n_treat <= 0 or n_control <= 0:
        return float("inf")
    z_alpha = stats.norm.ppf(1 - alpha / 2)
    z_power = stats.norm.ppf(power)
    se = sd * np.sqrt(1.0 / n_treat + 1.0 / n_control)
    return float((z_alpha + z_power) * se)


def mde_relative(
    sd: float,
    baseline_mean: float,
    n_treat: int,
    n_control: int,
    alpha: float = 0.05,
    power: float = 0.80,
) -> float:
    """MDE expressed as a fraction of the baseline mean (i.e. a % lift)."""
    if baseline_mean == 0:
        return float("inf")
    return mde_two_sample(sd, n_treat, n_control, alpha, power) / baseline_mean


def user_level_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    MDE for a user-level holdout across holdout fractions.

    The trade-off: a bigger holdout gives more statistical power but costs
    more forgone revenue. This table is how you price that trade-off.
    """
    sd = float(df["revenue"].std())
    baseline = float(df.loc[df["treated"] == 0, "revenue"].mean())
    n_total = len(df)

    rows = []
    for holdout in [0.05, 0.10, 0.20, 0.30, 0.50]:
        n_control = int(n_total * holdout)
        n_treat = n_total - n_control
        rows.append(
            {
                "holdout_pct": f"{holdout:.0%}",
                "n_control": n_control,
                "n_treated": n_treat,
                "mde_pct_lift": mde_relative(sd, baseline, n_treat, n_control),
            }
        )
    out = pd.DataFrame(rows)
    out["mde_pct_lift"] = (out["mde_pct_lift"] * 100).round(2)
    return out


def geo_level_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    MDE for a geo experiment across market counts and durations.

    The critical difference from a user-level test: the unit of randomisation
    is the MARKET, not the week and not the customer. Forty markets means
    n = 40, however many weeks you run and however many customers live in them.
    Running longer reduces the noise in each market's average, but it does not
    increase the number of units.

    This is why geo tests need larger effects than user-level tests, and why
    "we have millions of customers" is not an answer to "how many units do you
    have?"
    """
    # IMPORTANT: the relevant variance is NOT the variance of market levels.
    #
    # Markets differ enormously in size - a big city does 10x a small one -
    # but difference-in-differences removes each market's own baseline, so
    # that between-market variation never enters the comparison. Powering a
    # geo test off the SD of market levels massively overstates the
    # detectable effect (it is a common and expensive mistake).
    #
    # What matters is the SD across markets of each market's PRE-TO-POST
    # CHANGE, because that is the quantity being compared between arms.
    work = df.copy()
    work["log_sales"] = np.log(work["sales"])
    first_post_week = int(work.loc[work["post"] == 1, "week"].min())

    rows = []
    for n_weeks in [2, 4, 8]:
        pre = work[(work["post"] == 0) & (work["week"] >= first_post_week - n_weeks)]
        post = work[(work["post"] == 1) & (work["week"] < first_post_week + n_weeks)]

        pre_mean = pre.groupby("market")["log_sales"].mean()
        post_mean = post.groupby("market")["log_sales"].mean()
        # Per-market change, in logs. Market size has been differenced out.
        delta = (post_mean - pre_mean).dropna()
        sd_log = float(delta.std())

        for n_markets in [20, 40, 80, 200]:
            n_treat = n_markets // 2
            n_ctrl = n_markets - n_treat
            # In logs, an absolute MDE of x corresponds to a relative lift
            # of exp(x) - 1.
            mde_log = mde_two_sample(sd_log, n_treat, n_ctrl)
            rows.append(
                {
                    "weeks_each_side": n_weeks,
                    "n_markets": n_markets,
                    "sd_log_change": round(sd_log, 4),
                    "mde_pct_lift": round((np.expm1(mde_log)) * 100, 2),
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    banner("USER-LEVEL HOLDOUT: MDE BY HOLDOUT SIZE")

    users, utruth = make_user_experiment(n_users=80_000, true_lift=0.03)
    kv("Users", f"{len(users):,}")
    kv("Revenue SD (per user)", f"{users['revenue'].std():.2f}")
    kv("Control mean revenue", f"{users.loc[users.treated == 0, 'revenue'].mean():.2f}")
    kv("True lift in this dataset", f"{utruth['true_lift']:.1%}")
    print()
    print(user_level_table(users).to_string(index=False))
    print()
    print(
        "Read it like this: with a 10% holdout you can detect roughly the\n"
        "value in the mde_pct_lift column. If you believe the real effect is\n"
        "3% and the table says you can only detect 5%, the test is not worth\n"
        "running as designed - widen the holdout or extend the duration."
    )

    banner("GEO EXPERIMENT: MDE BY MARKET COUNT AND DURATION")

    geo, gtruth = make_geo_experiment(n_markets=200, n_weeks_post=8, true_lift=0.06)
    kv("True lift in this dataset", f"{gtruth['true_lift']:.1%}")
    print()
    print(geo_level_table(geo).to_string(index=False))
    print()
    print(
        "Three things to notice.\n\n"
        "1. Both levers work, and market count works harder. At 2 weeks a\n"
        "   side, going from 20 to 200 markets cuts the detectable effect by\n"
        "   about two thirds; at 20 markets, going from 2 to 8 weeks cuts it\n"
        "   by closer to a half. Markets add units; weeks only measure each\n"
        "   unit more precisely.\n\n"
        "2. At 20 markets you need a lift in the 6-11% range before the test\n"
        "   can see it. Plenty of real channel effects are smaller than that,\n"
        "   which is worth knowing before you spend a quarter finding out.\n\n"
        "3. The 6% true lift in this dataset is detectable at 40 markets with\n"
        "   8 weeks a side (MDE 4.3%), and not at 40 markets with 2 weeks\n"
        "   (MDE 7.8%). Same budget, same markets - the duration decision\n"
        "   alone determines whether you learn anything."
    )

    banner("THE COMPARISON THAT ACTUALLY MATTERS")

    sd = float(users["revenue"].std())
    baseline = float(users.loc[users.treated == 0, "revenue"].mean())
    n_ctrl = int(len(users) * 0.10)
    detectable = mde_relative(sd, baseline, len(users) - n_ctrl, n_ctrl)
    plausible = 0.03

    kv("Detectable at 10% holdout, 80% power", f"{detectable:.2%}")
    kv("Plausible effect (your prior)", f"{plausible:.2%}")
    print()
    if detectable > plausible:
        print(
            "DETECTABLE > PLAUSIBLE. Do not run this test as designed.\n"
            "Options: larger holdout, longer runtime, a bigger spend change,\n"
            "a less noisy outcome metric, or accept that this channel cannot\n"
            "be tested at your scale and let MMM carry it."
        )
    else:
        print("DETECTABLE < PLAUSIBLE. The design can see the effect you expect.")


if __name__ == "__main__":
    main()
