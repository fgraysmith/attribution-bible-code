"""
Chapter 12 - CUPED: variance reduction using pre-period data.

Chapter 11 said that if your minimum detectable effect is larger than the
effect you expect, don't run the test. CUPED is one of the few ways to improve
that situation without spending more money or waiting longer.

The idea: you already know something about each user before the test starts -
what they spent last quarter. Users who spent a lot before tend to spend a lot
after. That predictable component is noise as far as your treatment effect is
concerned, and you can subtract it out.

    Y_adjusted = Y - theta * (X - mean(X))

where X is the pre-period covariate and theta = cov(Y, X) / var(X).

The adjustment is unbiased because it subtracts a term with expectation zero.
The variance reduction is 1 - rho^2, where rho is the correlation between Y
and X. With rho = 0.45 you remove about 20% of the variance - which buys you
roughly the same precision as a 20% larger sample, for free.

CUPED comes from a 2013 Microsoft paper (Deng, Xu, Kohavi, Walker) and is
standard practice at most large experimentation platforms.

Run:  python 04_cuped.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from shared.synthetic_data import banner, kv, make_user_experiment


def simple_difference(df: pd.DataFrame, outcome: str = "revenue") -> dict:
    """Standard two-sample comparison of means, with a 95% CI on the lift."""
    treat = df.loc[df["treated"] == 1, outcome].to_numpy()
    ctrl = df.loc[df["treated"] == 0, outcome].to_numpy()

    diff = treat.mean() - ctrl.mean()
    se = np.sqrt(treat.var(ddof=1) / len(treat) + ctrl.var(ddof=1) / len(ctrl))
    z = stats.norm.ppf(0.975)

    return {
        "control_mean": float(ctrl.mean()),
        "abs_diff": float(diff),
        "se": float(se),
        "lift": float(diff / ctrl.mean()),
        "ci_lift": (
            float((diff - z * se) / ctrl.mean()),
            float((diff + z * se) / ctrl.mean()),
        ),
        "p_value": float(2 * (1 - stats.norm.cdf(abs(diff / se)))),
    }


def apply_cuped(df: pd.DataFrame, outcome: str = "revenue", covariate: str = "pre_revenue") -> tuple[pd.DataFrame, float]:
    """
    Add a CUPED-adjusted outcome column.

    theta is estimated on the POOLED data (both arms together). This is the
    standard approach and it is important: estimating theta separately per arm,
    or using the post-period outcome to pick the covariate, reintroduces the
    bias CUPED is supposed to avoid.

    The covariate must be measured BEFORE treatment begins. Any variable that
    treatment could have influenced is disqualified - using a post-treatment
    covariate will quietly bias your estimate rather than just reduce variance.
    """
    y = df[outcome].to_numpy()
    x = df[covariate].to_numpy()

    theta = float(np.cov(y, x, ddof=1)[0, 1] / np.var(x, ddof=1))

    out = df.copy()
    out[f"{outcome}_cuped"] = y - theta * (x - x.mean())
    return out, theta


def main() -> None:
    df, truth = make_user_experiment(
        n_users=80_000,
        true_lift=0.03,
        pre_period_correlation=0.6,
        seed=7,
    )

    banner("THE DATA")
    kv("Users", f"{len(df):,}")
    kv("  treated / control",
       f"{int(df.treated.sum()):,} / {int((1 - df.treated).sum()):,}")
    kv("Mean revenue (control)", f"{df.loc[df.treated == 0, 'revenue'].mean():.2f}")
    kv("Revenue SD", f"{df['revenue'].std():.2f}")
    kv("Zero-revenue users", f"{(df['revenue'] == 0).mean():.1%}")
    kv("Pre/post correlation (realised)", f"{truth['observed_pre_post_corr']:.3f}")
    kv("TRUE LIFT", f"{truth['true_lift']:.2%}")

    banner("1. WITHOUT CUPED")
    plain = simple_difference(df, "revenue")
    kv("Estimated lift", f"{plain['lift']:.2%}")
    kv("95% CI", f"[{plain['ci_lift'][0]:.2%}, {plain['ci_lift'][1]:.2%}]")
    kv("CI width (percentage points)",
       f"{(plain['ci_lift'][1] - plain['ci_lift'][0]) * 100:.2f}")
    kv("p-value", f"{plain['p_value']:.4f}")

    banner("2. WITH CUPED")
    adj, theta = apply_cuped(df, "revenue", "pre_revenue")
    cuped = simple_difference(adj, "revenue_cuped")

    kv("theta (regression coefficient)", f"{theta:.4f}")
    kv("Estimated lift", f"{cuped['lift']:.2%}")
    kv("95% CI", f"[{cuped['ci_lift'][0]:.2%}, {cuped['ci_lift'][1]:.2%}]")
    kv("CI width (percentage points)",
       f"{(cuped['ci_lift'][1] - cuped['ci_lift'][0]) * 100:.2f}")
    kv("p-value", f"{cuped['p_value']:.4f}")

    banner("3. WHAT YOU GAINED")
    var_plain = float(df["revenue"].var(ddof=1))
    var_cuped = float(adj["revenue_cuped"].var(ddof=1))
    rho = truth["observed_pre_post_corr"]

    kv("Variance before", f"{var_plain:,.1f}")
    kv("Variance after", f"{var_cuped:,.1f}")
    kv("Variance reduction (observed)", f"{1 - var_cuped / var_plain:.1%}")
    kv("Variance reduction (theory: 1-rho^2)", f"{rho**2:.1%}")
    print()

    se_ratio = cuped["se"] / plain["se"]
    kv("SE ratio (cuped / plain)", f"{se_ratio:.4f}")
    kv("Equivalent sample size multiplier", f"{1 / se_ratio**2:.2f}x")
    print()
    w_plain = (plain["ci_lift"][1] - plain["ci_lift"][0]) * 100
    w_cuped = (cuped["ci_lift"][1] - cuped["ci_lift"][0]) * 100
    print(
        f"The confidence interval narrowed from {w_plain:.2f} to {w_cuped:.2f}\n"
        f"percentage points. In sample-size terms, CUPED bought the precision\n"
        f"of a {1 / se_ratio**2:.2f}x larger experiment - at no cost in budget or\n"
        "runtime, using data you already had before the test started.\n\n"
        "Note how exactly the observed variance reduction matches the 1-rho^2\n"
        "prediction. That is a useful implementation check: if your observed\n"
        "reduction is far from rho^2, something is wrong with your covariate."
    )

    banner("4. THE SAME TEST, WITH A SMALLER SAMPLE")
    print(
        "The practical payoff: CUPED makes a given sample more precise.\n"
        "Here is the same experiment on a 40,000-user subsample.\n"
    )
    sub = df.sample(n=40_000, random_state=1)
    sub_plain = simple_difference(sub, "revenue")
    sub_adj, _ = apply_cuped(sub, "revenue", "pre_revenue")
    sub_cuped = simple_difference(sub_adj, "revenue_cuped")

    table = pd.DataFrame(
        [
            {
                "method": "plain",
                "lift": f"{sub_plain['lift']:.2%}",
                "ci_low": f"{sub_plain['ci_lift'][0]:.2%}",
                "ci_high": f"{sub_plain['ci_lift'][1]:.2%}",
                "ci_width_pp": round(
                    (sub_plain["ci_lift"][1] - sub_plain["ci_lift"][0]) * 100, 2
                ),
                "p": f"{sub_plain['p_value']:.4f}",
            },
            {
                "method": "CUPED",
                "lift": f"{sub_cuped['lift']:.2%}",
                "ci_low": f"{sub_cuped['ci_lift'][0]:.2%}",
                "ci_high": f"{sub_cuped['ci_lift'][1]:.2%}",
                "ci_width_pp": round(
                    (sub_cuped["ci_lift"][1] - sub_cuped["ci_lift"][0]) * 100, 2
                ),
                "p": f"{sub_cuped['p_value']:.4f}",
            },
        ]
    )
    print(table.to_string(index=False))
    print()
    print(
        "Read the ci_width column, not the p column.\n\n"
        "CUPED narrowed the interval - that is the guaranteed effect, and it is\n"
        "what CUPED does. The p-value went the other way, because the point\n"
        "estimate also moved (down, on this particular subsample) and the\n"
        "p-value depends on both. On a different draw it would go the other way.\n\n"
        "This is a concrete case for the habit of reporting intervals rather\n"
        "than significance. A method that reliably improves precision can still\n"
        "produce a less significant result on any single run, and if you are\n"
        "managing to the p-value you will draw the wrong conclusion about the\n"
        "method as well as about the channel."
    )

    banner("5. CHECKING THAT CUPED IS NOT CHEATING")
    print(
        "A variance reduction that also shifted the estimate would be a bias,\n"
        "not an improvement. Two checks worth running every time.\n"
    )
    shift = abs(plain["lift"] - cuped["lift"])
    kv("Point estimate, plain", f"{plain['lift']:.3%}")
    kv("Point estimate, CUPED", f"{cuped['lift']:.3%}")
    kv("Difference", f"{shift:.3%}")
    kv("Difference as share of CI width", f"{shift / (w_cuped / 100):.0%}")
    print()

    # The covariate must be balanced across arms. If it is not, randomisation
    # had a problem and CUPED is adjusting for a real pre-existing difference
    # rather than just removing noise.
    pre_t = df.loc[df.treated == 1, "pre_revenue"]
    pre_c = df.loc[df.treated == 0, "pre_revenue"]
    tstat, pval = stats.ttest_ind(pre_t, pre_c, equal_var=False)
    kv("Pre-period mean, treated", f"{pre_t.mean():.3f}")
    kv("Pre-period mean, control", f"{pre_c.mean():.3f}")
    kv("Balance check p-value", f"{pval:.3f}")
    print()
    print(
        "The two point estimates differ by a small fraction of the interval\n"
        "width, which is what noise looks like - CUPED is reweighting individual\n"
        "users' contributions, so the estimate moves a little. What you are\n"
        "checking for is a systematic shift much larger than this, which would\n"
        "indicate the covariate is contaminated by treatment.\n\n"
        "The balance check should come back non-significant. If the pre-period\n"
        "covariate differs between arms, your randomisation is suspect, and that\n"
        "is a problem to investigate rather than adjust away."
    )

    banner("WHEN CUPED HELPS, AND WHEN IT DOES NOT")
    print(
        "It helps in proportion to rho^2, so:\n\n"
        "  rho = 0.3  ->   9% variance reduction (marginal)\n"
        "  rho = 0.5  ->  25% variance reduction (worth having)\n"
        "  rho = 0.7  ->  49% variance reduction (substantial)\n\n"
        "Which means it works best for repeat-purchase businesses where past\n"
        "behaviour predicts future behaviour, and barely at all for one-off\n"
        "purchases or brand-new customers with no history.\n\n"
        "Three rules. The covariate must be measured strictly before treatment.\n"
        "Estimate theta on the pooled data, not per arm. And check that the\n"
        "point estimate only wanders within noise - a shift comparable to the\n"
        "interval width means the covariate is picking up treatment, and you are\n"
        "biasing the result rather than sharpening it."
    )


if __name__ == "__main__":
    main()
