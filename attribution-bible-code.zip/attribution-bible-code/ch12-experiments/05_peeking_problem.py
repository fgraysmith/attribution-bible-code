"""
Chapter 12 - The peeking problem, and what to do instead.

Chapter 11 says: pick an end date and wait for it. This script shows what
happens when you don't.

Everyone peeks. The dashboard is right there, the test is costing money, and
somebody senior asks how it's going. The trouble is that "stop as soon as it
looks significant" is a procedure with a much higher false positive rate than
the 5% the p-value appears to promise - because you are taking many chances
to cross the threshold instead of one.

This script simulates it:

  1. Measure the real false positive rate under repeated peeking, when the
     true effect is exactly zero.
  2. Show why it happens, by watching p-values wander.
  3. Fix it two ways: a Bonferroni-style correction (simple, conservative)
     and an alpha-spending boundary (the standard approach, better power).

Everything below runs under the null hypothesis - there is NO real effect in
any of this data. Every "significant" result is a false positive by
construction.

Run:  python 05_peeking_problem.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from shared.synthetic_data import banner, kv


def simulate_one_test(
    rng: np.random.Generator,
    n_per_arm: int,
    n_looks: int,
    effect: float = 0.0,
    sd: float = 1.0,
) -> np.ndarray:
    """
    Simulate one experiment that accumulates data, returning the z-statistic
    at each interim look.

    Data arrives in `n_looks` equal batches. At each look we compute the
    z-statistic on everything collected so far - which is exactly what a
    dashboard does when you refresh it.

    With effect=0 there is no true difference, so any crossing of a
    significance threshold is a false positive.
    """
    batch = max(n_per_arm // n_looks, 1)

    treat = rng.normal(effect, sd, size=n_per_arm)
    ctrl = rng.normal(0.0, sd, size=n_per_arm)

    z_at_look = np.empty(n_looks)
    for i in range(n_looks):
        n = min((i + 1) * batch, n_per_arm)
        t, c = treat[:n], ctrl[:n]
        diff = t.mean() - c.mean()
        se = np.sqrt(t.var(ddof=1) / n + c.var(ddof=1) / n)
        z_at_look[i] = diff / se if se > 0 else 0.0

    return z_at_look


def false_positive_rate(
    n_looks: int,
    n_sims: int = 4000,
    n_per_arm: int = 20_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> dict:
    """
    Estimate the false positive rate of "stop when significant" under the null.

    Two numbers come back:
      - fpr_peeking : rejected at ANY look (the stop-early procedure)
      - fpr_final   : rejected at the FINAL look only (the honest procedure)

    The second should land near alpha. The first will not.
    """
    rng = np.random.default_rng(seed)
    crit = stats.norm.ppf(1 - alpha / 2)

    any_cross = 0
    final_cross = 0
    for _ in range(n_sims):
        z = simulate_one_test(rng, n_per_arm, n_looks)
        if np.any(np.abs(z) >= crit):
            any_cross += 1
        if abs(z[-1]) >= crit:
            final_cross += 1

    return {
        "n_looks": n_looks,
        "fpr_peeking": any_cross / n_sims,
        "fpr_final": final_cross / n_sims,
    }


def obrien_fleming_bounds(
    n_looks: int, alpha: float = 0.05, n_calib: int = 20_000, seed: int = 123
) -> np.ndarray:
    """
    O'Brien-Fleming sequential boundaries, calibrated by simulation.

    The classic O'Brien-Fleming shape is

        z_k = c * sqrt(K / k)

    for look k of K: demanding early, when you have little information and the
    estimate is unstable, relaxing to its lowest value at the final look. The
    shape spends very little of the error budget early and most of it at the
    end.

    The constant `c` has to be chosen so the OVERALL false positive rate across
    all looks equals alpha. There is no closed form, because successive looks
    are correlated - they share data. Production tools solve it by numerical
    integration over the joint distribution; here we calibrate it directly by
    simulating the null and bisecting on c, which is slower but transparent and
    independently checkable.

    Calibrating rather than approximating matters. The common shortcut of
    converting each look's incremental alpha into a z threshold independently
    ignores that correlation and comes out materially conservative - it will
    hold your false positive rate well under alpha and cost you power you did
    not need to give up.

    The simulation uses Brownian motion increments, which is the standard
    large-sample approximation to an accumulating z-statistic.
    """
    rng = np.random.default_rng(seed)
    k = np.arange(1, n_looks + 1)
    shape = np.sqrt(n_looks / k)

    # Partial sums of iid increments, scaled to unit variance at each look:
    # this is the null distribution of the accumulating z-statistic.
    increments = rng.normal(0.0, 1.0, size=(n_calib, n_looks))
    cumulative = np.cumsum(increments, axis=1)
    z_paths = cumulative / np.sqrt(k)

    def fpr(c: float) -> float:
        return float(np.mean(np.any(np.abs(z_paths) >= c * shape, axis=1)))

    # Bisect on c. Larger c means stricter boundaries and a lower FPR.
    lo, hi = 0.5, 5.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if fpr(mid) > alpha:
            lo = mid
        else:
            hi = mid

    return (lo + hi) / 2 * shape


def evaluate_corrections(
    n_looks: int = 10,
    n_sims: int = 4000,
    n_per_arm: int = 20_000,
    alpha: float = 0.05,
    sd_pooled: float = 1.0,
    seed: int = 1,
) -> pd.DataFrame:
    """
    Compare three stopping procedures under the null, plus their power
    against a real effect.

    A correction that controls the false positive rate by never rejecting
    anything would be useless, so both columns matter: false positive rate
    under no effect, and detection rate when an effect is really there.
    """
    crit_naive = stats.norm.ppf(1 - alpha / 2)
    crit_bonf = stats.norm.ppf(1 - (alpha / n_looks) / 2)
    crit_obf = obrien_fleming_bounds(n_looks, alpha)

    def run(effect: float, seed_offset: int) -> dict:
        rng = np.random.default_rng(seed + seed_offset)
        hits = {"naive": 0, "bonferroni": 0, "obrien_fleming": 0, "final_only": 0}
        for _ in range(n_sims):
            z = np.abs(simulate_one_test(rng, n_per_arm, n_looks, effect=effect))
            if np.any(z >= crit_naive):
                hits["naive"] += 1
            if np.any(z >= crit_bonf):
                hits["bonferroni"] += 1
            if np.any(z >= crit_obf):
                hits["obrien_fleming"] += 1
            if z[-1] >= crit_naive:
                hits["final_only"] += 1
        return {k: v / n_sims for k, v in hits.items()}

    # Effect size chosen to give the honest single-look test roughly 80% power,
    # so the power comparison is on a realistic footing. For a two-sample
    # comparison the SE of the difference is sd*sqrt(2/n), and z = 2.8
    # corresponds to about 80% power at alpha = 0.05.
    effect = 2.8 * sd_pooled * np.sqrt(2.0 / n_per_arm)

    null = run(0.0, 0)
    alt = run(effect, 500)

    return pd.DataFrame(
        [
            {
                "procedure": name,
                "false_positive_rate": round(null[name], 4),
                "power_vs_real_effect": round(alt[name], 4),
            }
            for name in ["naive", "bonferroni", "obrien_fleming", "final_only"]
        ]
    )


def main() -> None:
    banner("1. HOW BAD IS PEEKING?")
    print(
        "Simulated experiments with NO real effect. We stop as soon as the\n"
        "result looks significant at the 5% level. If the procedure were sound,\n"
        "5% of these would come back significant.\n"
    )

    rows = []
    for n_looks in [1, 2, 5, 10, 20]:
        rows.append(false_positive_rate(n_looks, n_sims=3000, seed=0))
    table = pd.DataFrame(rows)
    table["fpr_peeking"] = (table["fpr_peeking"] * 100).round(1)
    table["fpr_final"] = (table["fpr_final"] * 100).round(1)
    table.columns = ["n_looks", "stop_when_significant_%", "final_look_only_%"]
    print(table.to_string(index=False))
    print()
    print(
        "With a single look the rate is about 5%, as advertised. By ten looks,\n"
        "stopping when significant roughly triples it. Check daily for three\n"
        "weeks and you are nearer one in three.\n\n"
        "The right-hand column is the control: waiting for the final look holds\n"
        "the rate at 5% no matter how many times you LOOKED, as long as looking\n"
        "did not change when you stopped. Peeking is not the sin. Stopping\n"
        "early because of what you saw is the sin."
    )

    banner("2. WHY IT HAPPENS")
    rng = np.random.default_rng(99)
    crit = stats.norm.ppf(0.975)

    print(
        "Five simulated null experiments, showing the z-statistic at each of\n"
        "10 looks. Nothing here has a real effect. Values beyond +/-1.96 are\n"
        "marked - those are the moments an eager analyst would have stopped.\n"
    )
    for i in range(5):
        z = simulate_one_test(rng, n_per_arm=20_000, n_looks=10)
        marks = "".join("*" if abs(v) >= crit else "." for v in z)
        crossed = "  <-- would have stopped early" if np.any(np.abs(z) >= crit) else ""
        print(f"  test {i + 1}: {marks}  final z={z[-1]:+.2f}{crossed}")
    print()
    print(
        "The z-statistic wanders. Early on there is little data, so it wanders\n"
        "a lot. Give it ten chances to stray past the threshold and sooner or\n"
        "later it will, with no effect to find."
    )

    banner("3. TWO WAYS TO FIX IT")
    bounds = obrien_fleming_bounds(10, 0.05)
    print("O'Brien-Fleming boundaries for 10 looks (|z| must exceed):\n")
    for i, b in enumerate(bounds, start=1):
        bar = "#" * int(round(b * 4))
        print(f"  look {i:2d}:  {b:5.2f}  {bar}")
    crit_bonf = stats.norm.ppf(1 - (0.05 / 10) / 2)
    print()
    print(
        f"Demanding early, relaxing later. At the first look you need\n"
        f"|z| > {bounds[0]:.2f} to stop - a bar only a genuinely large effect clears.\n"
        f"By the last look the threshold has come down to {bounds[-1]:.2f}, close to the\n"
        "familiar 1.96.\n\n"
        "Compare with Bonferroni, which splits alpha evenly across looks:\n"
        f"  a constant threshold of |z| > {crit_bonf:.2f} at every look.\n\n"
        "Bonferroni is easier to explain. O'Brien-Fleming is stricter than it\n"
        "early and more lenient late, which is the better trade - early looks\n"
        "rest on little data and are where spurious crossings happen, while by\n"
        "the final look you want something close to the ordinary threshold."
    )

    banner("4. DO THE CORRECTIONS WORK?")
    print(
        "False positive rate under no effect, and power against a real effect\n"
        "sized so an honest single-look test would detect it about 80% of the\n"
        "time. Both columns matter: a procedure that never rejects anything\n"
        "controls false positives perfectly and is worthless.\n"
    )
    results = evaluate_corrections(n_looks=10, n_sims=3000)
    print(results.to_string(index=False))
    print()
    print(
        "Read that table carefully, because the three rows say different things.\n\n"
        "The naive procedure is badly miscalibrated - it rejects roughly four\n"
        "times as often as it should. Its apparently high power is not a virtue;\n"
        "it is the same defect seen from the other side, since a procedure that\n"
        "fires too easily fires on real effects and noise alike.\n\n"
        "Bonferroni controls the error rate but overshoots, landing well under\n"
        "the nominal 5%, and that conservatism is expensive: it gives up a large\n"
        "share of the power. It is safe and blunt.\n\n"
        "O'Brien-Fleming is the one to use. It hits the nominal rate almost\n"
        "exactly and retains nearly all the power of the honest fixed-horizon\n"
        "test - so the option to stop early costs you very little, provided the\n"
        "boundary was set before launch.\n\n"
        "'final_only' is the Chapter 11 recommendation: fix an end date, look as\n"
        "often as you like, decide once. Best power, no correction needed.\n\n"
        "So: if you can commit to an end date, do that. If you genuinely need the\n"
        "option to stop early - a test that might be harming revenue, say - use a\n"
        "sequential boundary and write it into the analysis plan before launch.\n"
        "What you cannot do is watch a dashboard, stop when it looks good, and\n"
        "report the p-value as though you had only looked once."
    )


if __name__ == "__main__":
    main()
