# Chapter 12 — Evaluating a Controlled Experiment

Run them in order; each builds on the last.

```bash
python 01_power_and_mde.py              # before you launch
python 02_difference_in_differences.py  # the core estimator
python 03_synthetic_control.py          # when DiD isn't enough
python 04_cuped.py                      # more precision, same sample
python 05_peeking_problem.py            # why you don't stop early
```

`05_peeking_problem.py` runs a few thousand simulations and takes a minute or two. The rest are near-instant.

## What each one establishes

**01 — Power and MDE.** The calculation Chapter 11 says to run before committing budget. Two tables: MDE by holdout size for a user-level test, and MDE by market count and duration for a geo test. The geo table makes a point worth internalising — market count is the binding constraint, and "we have millions of customers" is not an answer to "how many units do you have?"

Note the deliberate correction in `geo_level_table`: power comes from the SD of each market's pre-to-post *change*, not the SD of market levels. Markets differ enormously in size, but DiD differences that away. Powering off levels overstates the detectable effect badly.

**02 — Difference-in-differences.** The naive pre/post comparison overstates a true 6% lift by 97%, because the post period contains a seasonal ramp. DiD removes it without modelling it — that's what randomisation buys.

Then the standard-error question. Clustering at the market level multiplies the SE by about 2.4x here, because weekly sales within a market are autocorrelated. Treating 1,360 market-weeks as 1,360 independent observations would report well under half the uncertainty you actually have. Randomisation inference is included as a check, since cluster-robust errors lean optimistic below ~50 clusters.

**03 — Synthetic control.** Per-market estimates range from −28% to +31% against a true 15% — which is why "it worked in Market A and failed in Market B" is almost always noise. Aggregate the treated markets first and the estimate behaves. Pre-period fit is the diagnostic that gates everything, and inference is by placebo test rather than standard errors.

**04 — CUPED.** Subtracting the predictable part of each user's behaviour removes about 20% of the variance here — the precision of a 1.25× larger experiment, free, from data you already had.

Also a worked case for reporting intervals over significance: on one subsample CUPED narrows the interval *and* raises the p-value, because the point estimate moved too. Manage to the p-value and you'd conclude CUPED hurt.

**05 — The peeking problem.** Under the null, "stop when significant" rejects about 20% of the time at ten looks instead of 5%. Two fixes: Bonferroni (safe, blunt, costs real power) and O'Brien-Fleming (hits the nominal rate, keeps nearly all the power). Boundaries are calibrated by simulation rather than approximated, because the common shortcut of converting incremental alpha independently per look ignores the correlation between looks and comes out materially conservative.

The headline: a fixed end date has the best power of any procedure here and needs no correction at all.
