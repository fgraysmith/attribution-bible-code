# Chapter 13 — Implementing a Multi-Touch Attribution Model

Code lands when the chapter publishes (5 November 2026).

Path data construction, Markov chain removal effects, Shapley values (exact and sampled), handling non-converting paths, and validating MTA output against experimental ground truth.

The validation piece is the one that matters: Chapter 3 argues MTA is a budgeting and pacing tool rather than an incrementality measure, and this code shows what happens when you check its channel estimates against a holdout result.
